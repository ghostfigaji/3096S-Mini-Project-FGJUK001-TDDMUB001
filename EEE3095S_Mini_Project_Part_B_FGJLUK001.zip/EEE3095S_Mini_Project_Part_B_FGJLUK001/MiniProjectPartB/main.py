import serial
import sys

serialPort = serial.Serial(port="COM4", baudrate=9600, bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)

serialString = ""
decodedString = ""
sampleData = ""

file = open("sampleData.csv", "a")

print("Welcome to the EEE3095S Part B Console Control.")
print("Author: Luke Figaji")
print("-----------------------------------------------")
print("A list of commands follows:")
print("A: Read the ADC and display it to the terminal, add it to log file.")
print("E: Echo test, displays last value received by serial connection.")
print("X: Exit.\n")

print("Please enter a command:")


while(True):
    for line in sys.stdin:
        if 'A' == line.rstrip():
            if serialPort.in_waiting > 0:
                serialString = serialPort.readline()
                decodedString = serialString.decode('Ascii')
                sampleData = decodedString[11:16] + ","
                file.write(sampleData)
                print(decodedString)
        elif 'E' == line.rstrip():
            print("Serial communication status:")
            if (serialPort.isOpen()):
                print("Open")
            else:
                print("Closed")
            print("Last communication from serial port: " + decodedString)
        elif 'X' == line.rstrip():
            print("Exit")
            file.close()
            sys.exit(0)
        print("Please enter a command:")

